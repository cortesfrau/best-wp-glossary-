=== WP Best Glossary ===
Contributors: cortesfrau
Donate link: http://lluiscortes.com
Tags: glossary
Requires at least: 4.7.0
Tested up to: 5.6
Requires PHP: 5.4
Stable tag: 1.0.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==

This plugin allows users to create a glossary page.

== Installation ==

1. Upload the entire `best-wp-glossary` folder to the `/wp-content/plugins/` directory.
1. Activate the plugin through the **Plugins** screen (**Plugins > Installed Plugins**).

== Screenshots ==

== Changelog ==
1.0.1 Minor style changes.

== Frequently Asked Questions ==

== Upgrade Notice ==
