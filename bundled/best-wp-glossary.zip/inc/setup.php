<?php

//------------------------//
//--- Custom IMG Sizes ---//
//------------------------//
add_image_size('bwpg_landscape_thumb', 720, 480, true);
